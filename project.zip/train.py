import torch
from LoadData import train_loader
from torch.autograd import Variable
from torch import nn
from torchvision import models
import os
from U_Net import U_Net

EPOCH_NUM = 80
MODEL_PATH = 'models/transfer_resnet18.pkl'
N_CHANNEL = 3
N_CLASS = 1
LR = 1e-4
BATCH_NUM = 500

# if os.path.exists(r'transfer_resnet18.pkl'):
#     my_model = torch.load('transfer_resnet18.pkl').cuda()
#     print("model from load")
# else:
#     my_model = models.resnet18(pretrained=True).cuda()
#     torch.save(my_model, 'transfer_resnet18.pkl')
#     print("model build")

my_model = U_Net(N_CHANNEL, N_CLASS).cuda()
print(my_model)

criterion = torch.nn.CrossEntropyLoss().cuda()
optimizer = torch.optim.Adam(my_model.parameters(), lr=LR)

for epoch in range(EPOCH_NUM):
    for i, (images, labels) in enumerate(train_loader):
        images = Variable(images.cuda())
        labels = Variable(labels.long().cuda())

        # Forward + Backward + Optimize
        optimizer.zero_grad()
        outputs = my_model(images)
        loss = criterion(outputs, labels)
        # print(loss)
        loss.backward()
        optimizer.step()

        # if (i + 1) % 100 == 0:
        print("Epoch [%d/%d], Iter [%d/%d] Loss: %.4f" % (epoch + 1, EPOCH_NUM, i + 1, BATCH_NUM, loss.data[0]))
        torch.save(my_model, MODEL_PATH)